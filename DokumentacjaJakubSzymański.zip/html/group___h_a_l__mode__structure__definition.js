var group___h_a_l__mode__structure__definition =
[
    [ "HAL_I2C_ModeTypeDef", "group___h_a_l__mode__structure__definition.html#gabcbb7b844f2ffd63c4e530c117882062", [
      [ "HAL_I2C_MODE_NONE", "group___h_a_l__mode__structure__definition.html#ggabcbb7b844f2ffd63c4e530c117882062a98c8fd642b7ac45a23479bd597fc7a71", null ],
      [ "HAL_I2C_MODE_MASTER", "group___h_a_l__mode__structure__definition.html#ggabcbb7b844f2ffd63c4e530c117882062a1eea98660a170dd7b191c9dfe46da6d2", null ],
      [ "HAL_I2C_MODE_SLAVE", "group___h_a_l__mode__structure__definition.html#ggabcbb7b844f2ffd63c4e530c117882062a817358d19d278261f2047a5ec8ec6b53", null ],
      [ "HAL_I2C_MODE_MEM", "group___h_a_l__mode__structure__definition.html#ggabcbb7b844f2ffd63c4e530c117882062a3f592bd942f973242aac6b7df79f3f1e", null ]
    ] ]
];