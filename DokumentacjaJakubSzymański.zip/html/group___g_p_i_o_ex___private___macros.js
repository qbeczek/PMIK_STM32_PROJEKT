var group___g_p_i_o_ex___private___macros =
[
    [ "GPIO Get Port Index", "group___g_p_i_o_ex___get___port___index.html", null ],
    [ "GPIO Check Alternate Function", "group___g_p_i_o_ex___i_s___alternat__function__selection.html", null ]
];