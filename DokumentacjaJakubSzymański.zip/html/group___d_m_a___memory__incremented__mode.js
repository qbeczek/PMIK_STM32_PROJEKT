var group___d_m_a___memory__incremented__mode =
[
    [ "DMA_MINC_DISABLE", "group___d_m_a___memory__incremented__mode.html#ga32625330516c188151743473fad97a33", null ],
    [ "DMA_MINC_ENABLE", "group___d_m_a___memory__incremented__mode.html#ga43d30885699cc8378562316ff4fed1cd", null ]
];