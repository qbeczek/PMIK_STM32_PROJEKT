var group___c_o_r_t_e_x___preemption___priority___group =
[
    [ "NVIC_PRIORITYGROUP_0", "group___c_o_r_t_e_x___preemption___priority___group.html#ga5e97dcff77680602c86e44f23f5ffa1a", null ],
    [ "NVIC_PRIORITYGROUP_1", "group___c_o_r_t_e_x___preemption___priority___group.html#ga702227137b010421c3a3b6434005a132", null ],
    [ "NVIC_PRIORITYGROUP_2", "group___c_o_r_t_e_x___preemption___priority___group.html#gaa43a3fd37850c120ce567ab2743d11b4", null ],
    [ "NVIC_PRIORITYGROUP_3", "group___c_o_r_t_e_x___preemption___priority___group.html#ga8ddb24962e6f0fc3273139d45d374b09", null ],
    [ "NVIC_PRIORITYGROUP_4", "group___c_o_r_t_e_x___preemption___priority___group.html#gae6eab9140204bc938255aa148e597c45", null ]
];