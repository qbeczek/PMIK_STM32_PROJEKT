var group___d_m_a_ex___exported___types =
[
    [ "HAL_DMA_MemoryTypeDef", "group___d_m_a_ex___exported___types.html#ga9cec283a461e47eda968838c35fd6eed", [
      [ "MEMORY0", "group___d_m_a_ex___exported___types.html#gga9cec283a461e47eda968838c35fd6eeda2dec05a318eee29371114f1a8f6fe3f4", null ],
      [ "MEMORY1", "group___d_m_a_ex___exported___types.html#gga9cec283a461e47eda968838c35fd6eeda06080dfa68716b5bbf425d9232b144c3", null ]
    ] ]
];