var group___f_l_a_s_h_ex___voltage___range =
[
    [ "FLASH_VOLTAGE_RANGE_1", "group___f_l_a_s_h_ex___voltage___range.html#ga5cadf49a63c968cde3b980e5139d398e", null ],
    [ "FLASH_VOLTAGE_RANGE_2", "group___f_l_a_s_h_ex___voltage___range.html#gad047be2bc7aa9be946b5b0c6b3062ef3", null ],
    [ "FLASH_VOLTAGE_RANGE_3", "group___f_l_a_s_h_ex___voltage___range.html#ga50950407a789684eec9216f49e0831a0", null ],
    [ "FLASH_VOLTAGE_RANGE_4", "group___f_l_a_s_h_ex___voltage___range.html#gabf8037a482f18815c5a67f287223a658", null ]
];