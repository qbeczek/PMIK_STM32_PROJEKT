var dir_5037003aa53320d2928b8f7a9af24b55 =
[
    [ "workspace_IDE", "dir_9704fe18c807de38ee0e2b18590b8511.html", "dir_9704fe18c807de38ee0e2b18590b8511" ]
];