var group___configuration__section__for___c_m_s_i_s =
[
    [ "__CM4_REV", "group___configuration__section__for___c_m_s_i_s.html#ga45a97e4bb8b6ce7c334acc5f45ace3ba", null ],
    [ "__FPU_PRESENT", "group___configuration__section__for___c_m_s_i_s.html#gac1ba8a48ca926bddc88be9bfd7d42641", null ],
    [ "__MPU_PRESENT", "group___configuration__section__for___c_m_s_i_s.html#ga4127d1b31aaf336fab3d7329d117f448", null ],
    [ "__NVIC_PRIO_BITS", "group___configuration__section__for___c_m_s_i_s.html#gae3fe3587d5100c787e02102ce3944460", null ],
    [ "__Vendor_SysTickConfig", "group___configuration__section__for___c_m_s_i_s.html#gab58771b4ec03f9bdddc84770f7c95c68", null ]
];