var group___d_m_a___priority__level =
[
    [ "DMA_PRIORITY_HIGH", "group___d_m_a___priority__level.html#ga6b2f5c5e22895f8b4bd52a27ec6cae2a", null ],
    [ "DMA_PRIORITY_LOW", "group___d_m_a___priority__level.html#ga0d1ed2bc9229ba3c953002bcf3a72130", null ],
    [ "DMA_PRIORITY_MEDIUM", "group___d_m_a___priority__level.html#gad6fbeee76fd4a02cbed64365bb4c1781", null ],
    [ "DMA_PRIORITY_VERY_HIGH", "group___d_m_a___priority__level.html#gaed0542331a4d875d1d8d5b2878e9372c", null ]
];