var group___g_p_i_o__speed__define =
[
    [ "GPIO_SPEED_FREQ_HIGH", "group___g_p_i_o__speed__define.html#gaef5898db71cdb957cd41f940b0087af8", null ],
    [ "GPIO_SPEED_FREQ_LOW", "group___g_p_i_o__speed__define.html#gab7916c4265bfa1b26a5205ea9c1caa4e", null ],
    [ "GPIO_SPEED_FREQ_MEDIUM", "group___g_p_i_o__speed__define.html#ga1724a25a9cf00ebf485daeb09cfa1e25", null ],
    [ "GPIO_SPEED_FREQ_VERY_HIGH", "group___g_p_i_o__speed__define.html#ga1944cf10e2ab172810d38b681d40b771", null ]
];