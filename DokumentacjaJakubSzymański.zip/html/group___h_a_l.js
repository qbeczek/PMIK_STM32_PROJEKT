var group___h_a_l =
[
    [ "HAL Exported Constants", "group___h_a_l___exported___constants.html", "group___h_a_l___exported___constants" ],
    [ "HAL Exported Macros", "group___h_a_l___exported___macros.html", "group___h_a_l___exported___macros" ],
    [ "HAL Private Macros", "group___h_a_l___private___macros.html", null ],
    [ "HAL Private Variables", "group___h_a_l___private___variables.html", null ],
    [ "HAL Private Constants", "group___h_a_l___private___constants.html", "group___h_a_l___private___constants" ],
    [ "HAL Exported Functions", "group___h_a_l___exported___functions.html", "group___h_a_l___exported___functions" ],
    [ "HAL_Exported_Variables", "group___h_a_l___exported___variables.html", null ]
];