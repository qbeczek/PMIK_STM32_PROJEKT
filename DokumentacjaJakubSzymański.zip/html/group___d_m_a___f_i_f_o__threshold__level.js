var group___d_m_a___f_i_f_o__threshold__level =
[
    [ "DMA_FIFO_THRESHOLD_1QUARTERFULL", "group___d_m_a___f_i_f_o__threshold__level.html#ga4debbd5733190b61b2115613d4b3658b", null ],
    [ "DMA_FIFO_THRESHOLD_3QUARTERSFULL", "group___d_m_a___f_i_f_o__threshold__level.html#gae1e4ba12bae8440421e6672795d71223", null ],
    [ "DMA_FIFO_THRESHOLD_FULL", "group___d_m_a___f_i_f_o__threshold__level.html#ga5de463bb24dc12fe7bbb300e1e4493f7", null ],
    [ "DMA_FIFO_THRESHOLD_HALFFULL", "group___d_m_a___f_i_f_o__threshold__level.html#gad2b071aa3a3bfc936017f12fb956c56f", null ]
];