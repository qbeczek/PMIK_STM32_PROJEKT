var group___f_l_a_s_h_ex___b_o_r___reset___level =
[
    [ "OB_BOR_LEVEL1", "group___f_l_a_s_h_ex___b_o_r___reset___level.html#ga3a888b788e75f0bc1f9add85c9ccd9d6", null ],
    [ "OB_BOR_LEVEL2", "group___f_l_a_s_h_ex___b_o_r___reset___level.html#gad678e849fcf817f6ed2d837538e8ebc2", null ],
    [ "OB_BOR_LEVEL3", "group___f_l_a_s_h_ex___b_o_r___reset___level.html#ga3132b8202c0a345e9dd33d136714b046", null ],
    [ "OB_BOR_OFF", "group___f_l_a_s_h_ex___b_o_r___reset___level.html#gaabc231cb1d05a94fe860f67bb5a37b12", null ]
];