var group___d_m_a___memory__data__size =
[
    [ "DMA_MDATAALIGN_BYTE", "group___d_m_a___memory__data__size.html#ga9ed07bddf736298eba11508382ea4d51", null ],
    [ "DMA_MDATAALIGN_HALFWORD", "group___d_m_a___memory__data__size.html#ga2c7355971c0da34a7ffe50ec87403071", null ],
    [ "DMA_MDATAALIGN_WORD", "group___d_m_a___memory__data__size.html#ga8812da819f18c873249074f3920220b2", null ]
];