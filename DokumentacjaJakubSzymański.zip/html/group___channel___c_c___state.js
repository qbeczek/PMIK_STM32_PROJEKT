var group___channel___c_c___state =
[
    [ "TIM_CCx_DISABLE", "group___channel___c_c___state.html#ga5068d16e01778cd3bd09555013b2f4d3", null ],
    [ "TIM_CCx_ENABLE", "group___channel___c_c___state.html#ga7b214df0d5c67138de7bc84e937909f0", null ],
    [ "TIM_CCxN_DISABLE", "group___channel___c_c___state.html#ga241183326d83407f7cc7dbd292533240", null ],
    [ "TIM_CCxN_ENABLE", "group___channel___c_c___state.html#ga69ecb0bf5dcd5ecf30af36d6fc00ea0d", null ]
];