var group___d_m_a___peripheral__data__size =
[
    [ "DMA_PDATAALIGN_BYTE", "group___d_m_a___peripheral__data__size.html#ga55b8c8f5ec95f10d26d6c5b1c9136730", null ],
    [ "DMA_PDATAALIGN_HALFWORD", "group___d_m_a___peripheral__data__size.html#gac08bfd907442dba5358830b247135bcc", null ],
    [ "DMA_PDATAALIGN_WORD", "group___d_m_a___peripheral__data__size.html#gaad50e97cbc4a726660db9c3f42ac93b0", null ]
];