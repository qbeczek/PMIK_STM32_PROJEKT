var group___d_m_a___f_i_f_o__direct__mode =
[
    [ "DMA_FIFOMODE_DISABLE", "group___d_m_a___f_i_f_o__direct__mode.html#gaec22b199f9da9214bf908d7edbcd83e8", null ],
    [ "DMA_FIFOMODE_ENABLE", "group___d_m_a___f_i_f_o__direct__mode.html#ga18709570bed6b9112520701c482fbe4b", null ]
];