var group___d_m_a___handle__index =
[
    [ "TIM_DMA_ID_CC1", "group___d_m_a___handle__index.html#ga7ca691eb5e29b0206d3390cc6e90079a", null ],
    [ "TIM_DMA_ID_CC2", "group___d_m_a___handle__index.html#ga9c52f32d4bd21dd2d232900219f0a111", null ],
    [ "TIM_DMA_ID_CC3", "group___d_m_a___handle__index.html#ga6e8145f305b54744bf2ef379a4315a40", null ],
    [ "TIM_DMA_ID_CC4", "group___d_m_a___handle__index.html#ga1860c00b370435ff40d9e65f14a61706", null ],
    [ "TIM_DMA_ID_COMMUTATION", "group___d_m_a___handle__index.html#gaa707c98bb11277665635ca7aef1e4193", null ],
    [ "TIM_DMA_ID_TRIGGER", "group___d_m_a___handle__index.html#ga39900e5227e4d813a726a1df5d86671c", null ],
    [ "TIM_DMA_ID_UPDATE", "group___d_m_a___handle__index.html#ga15f38cee11f8b2b5a85cbf4552ba140d", null ]
];