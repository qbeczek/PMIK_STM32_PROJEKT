var group___d_m_a_ex =
[
    [ "DMAEx Exported Types", "group___d_m_a_ex___exported___types.html", "group___d_m_a_ex___exported___types" ],
    [ "DMAEx Exported Functions", "group___d_m_a_ex___exported___functions.html", "group___d_m_a_ex___exported___functions" ],
    [ "DMAEx Private Functions", "group___d_m_a_ex___private___functions.html", null ]
];