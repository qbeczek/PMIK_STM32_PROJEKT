var bmp280_8c =
[
    [ "bmp280_compute_meas_time", "bmp280_8c.html#a7dbe28b4cc8930af9ff23d1fe566f0c6", null ],
    [ "bmp280_get_comp_pres_32bit", "bmp280_8c.html#aed425399b074d6541e8d74883dba2446", null ],
    [ "bmp280_get_comp_pres_64bit", "bmp280_8c.html#a0b090c0b8883517d20694e343c1f7df7", null ],
    [ "bmp280_get_comp_pres_double", "bmp280_8c.html#a1890d1009e829f08bfbfde4c9f3a09c9", null ],
    [ "bmp280_get_comp_temp_32bit", "bmp280_8c.html#ad1d9f81bb0a43c72195319d72d915367", null ],
    [ "bmp280_get_comp_temp_double", "bmp280_8c.html#a2699b3c803edf4918b684b694ce268fb", null ],
    [ "bmp280_get_config", "bmp280_8c.html#aded88d5f67beb1b3311bb0e26ecc19da", null ],
    [ "bmp280_get_power_mode", "bmp280_8c.html#ab1abf2ca4516a0e666469f7d57300c00", null ],
    [ "bmp280_get_regs", "bmp280_8c.html#a31f92833cdfbcf5d82ad8382c2b29749", null ],
    [ "bmp280_get_status", "bmp280_8c.html#a7f39644204f57cb6fc3eff936df2715f", null ],
    [ "bmp280_get_uncomp_data", "bmp280_8c.html#ae99e0ecdad4920b363d1c258887b4ff3", null ],
    [ "bmp280_init", "bmp280_8c.html#a4a9809dbaa4df084461c705045925f8e", null ],
    [ "bmp280_set_config", "bmp280_8c.html#a61799b86b24d68b7a20814fcaf9adea8", null ],
    [ "bmp280_set_power_mode", "bmp280_8c.html#a4401d930aa889a00121087f4aeac0182", null ],
    [ "bmp280_set_regs", "bmp280_8c.html#a2d41bc3f1cfccf3e250749a77723883b", null ],
    [ "bmp280_soft_reset", "bmp280_8c.html#ab3d06fdfe71e48cb081e1f66c14ba63f", null ]
];