var group___d_m_a___exported___constants =
[
    [ "DMA Error Code", "group___d_m_a___error___code.html", "group___d_m_a___error___code" ],
    [ "DMA Channel selection", "group___d_m_a___channel__selection.html", "group___d_m_a___channel__selection" ],
    [ "DMA Data transfer direction", "group___d_m_a___data__transfer__direction.html", "group___d_m_a___data__transfer__direction" ],
    [ "DMA Peripheral incremented mode", "group___d_m_a___peripheral__incremented__mode.html", "group___d_m_a___peripheral__incremented__mode" ],
    [ "DMA Memory incremented mode", "group___d_m_a___memory__incremented__mode.html", "group___d_m_a___memory__incremented__mode" ],
    [ "DMA Peripheral data size", "group___d_m_a___peripheral__data__size.html", "group___d_m_a___peripheral__data__size" ],
    [ "DMA Memory data size", "group___d_m_a___memory__data__size.html", "group___d_m_a___memory__data__size" ],
    [ "DMA mode", "group___d_m_a__mode.html", "group___d_m_a__mode" ],
    [ "DMA Priority level", "group___d_m_a___priority__level.html", "group___d_m_a___priority__level" ],
    [ "DMA FIFO direct mode", "group___d_m_a___f_i_f_o__direct__mode.html", "group___d_m_a___f_i_f_o__direct__mode" ],
    [ "DMA FIFO threshold level", "group___d_m_a___f_i_f_o__threshold__level.html", "group___d_m_a___f_i_f_o__threshold__level" ],
    [ "DMA Memory burst", "group___d_m_a___memory__burst.html", null ],
    [ "DMA Peripheral burst", "group___d_m_a___peripheral__burst.html", null ],
    [ "DMA interrupt enable definitions", "group___d_m_a__interrupt__enable__definitions.html", null ],
    [ "DMA flag definitions", "group___d_m_a__flag__definitions.html", null ]
];