var group___exported__macros =
[
    [ "FLASH_SCALE2_LATENCY1_FREQ", "group___exported__macros.html#ga19ba80e0c72cd041274f831901f302f9", null ],
    [ "FLASH_SCALE2_LATENCY2_FREQ", "group___exported__macros.html#ga98847021d5de23ea0458b490c74e6299", null ],
    [ "FLASH_SCALE3_LATENCY1_FREQ", "group___exported__macros.html#ga322840abc74aeafafe710d45e4f9c7cd", null ],
    [ "FLASH_SCALE3_LATENCY2_FREQ", "group___exported__macros.html#ga9a6fd257610db9111ae2a291825a86d0", null ],
    [ "RCC_MAX_FREQUENCY", "group___exported__macros.html#ga08aeea283003a2c787227347087b5b1f", null ],
    [ "RCC_MAX_FREQUENCY_SCALE2", "group___exported__macros.html#gafcb2c5211d9cbed86b111c83a0ce427b", null ],
    [ "RCC_MAX_FREQUENCY_SCALE3", "group___exported__macros.html#ga60fbed15643b623aa4541b9d8828d0f1", null ],
    [ "RCC_PLLVCO_INPUT_MAX", "group___exported__macros.html#gad3fd37dbfa74739a3c698ab4755fa27e", null ],
    [ "RCC_PLLVCO_INPUT_MIN", "group___exported__macros.html#ga288d68c2604cea8548eccdef3873923f", null ],
    [ "RCC_PLLVCO_OUTPUT_MAX", "group___exported__macros.html#gaba6ddae0375763847f8dc3e91173d714", null ],
    [ "RCC_PLLVCO_OUTPUT_MIN", "group___exported__macros.html#ga85746dffdc6d015f5142d7e16489ca84", null ]
];