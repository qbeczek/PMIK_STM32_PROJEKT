var group___d_m_a___channel__selection =
[
    [ "DMA_CHANNEL_0", "group___d_m_a___channel__selection.html#gabd7de138931e93a90fc6c4eab5916bbe", null ],
    [ "DMA_CHANNEL_1", "group___d_m_a___channel__selection.html#ga283364370e9876af6406b9fa70e2944f", null ],
    [ "DMA_CHANNEL_2", "group___d_m_a___channel__selection.html#ga9688f3e78cbc2109d214b7ca049e22df", null ],
    [ "DMA_CHANNEL_3", "group___d_m_a___channel__selection.html#gac689673fec4d72ede49a0d657e3a7e70", null ],
    [ "DMA_CHANNEL_4", "group___d_m_a___channel__selection.html#ga51b51f5b39e23b28ad99520ad5be596f", null ],
    [ "DMA_CHANNEL_5", "group___d_m_a___channel__selection.html#gafbaa82f3cff89858e50363c04ed0cca0", null ],
    [ "DMA_CHANNEL_6", "group___d_m_a___channel__selection.html#gad23679661d8da3bc1aaacc62f99821f7", null ],
    [ "DMA_CHANNEL_7", "group___d_m_a___channel__selection.html#ga77ff4e8675a3991feb20e385242f34ab", null ]
];