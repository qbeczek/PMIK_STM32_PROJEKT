var group___d_m_a___error___code =
[
    [ "HAL_DMA_ERROR_DME", "group___d_m_a___error___code.html#gabac48184446aea8f467483382fc6689b", null ],
    [ "HAL_DMA_ERROR_FE", "group___d_m_a___error___code.html#ga019411712b9aee1d34b57d029a461fa4", null ],
    [ "HAL_DMA_ERROR_NO_XFER", "group___d_m_a___error___code.html#gab7526e686427f26bf3b6af062d5a690b", null ],
    [ "HAL_DMA_ERROR_NONE", "group___d_m_a___error___code.html#gaad4009390bfbe05a1bb7115d03c25a97", null ],
    [ "HAL_DMA_ERROR_NOT_SUPPORTED", "group___d_m_a___error___code.html#ga7432f31f9972e1c0a398a3f20587d118", null ],
    [ "HAL_DMA_ERROR_PARAM", "group___d_m_a___error___code.html#ga5aaaad3b88a77147d1e3daa3a3ad9e60", null ],
    [ "HAL_DMA_ERROR_TE", "group___d_m_a___error___code.html#ga9882442c5f8f0170917934bbee1cc92d", null ],
    [ "HAL_DMA_ERROR_TIMEOUT", "group___d_m_a___error___code.html#ga6cf6a5b8881ff36ed4316a29bbfb5b79", null ]
];