var group___h_a_l__state__structure__definition =
[
    [ "HAL_I2C_StateTypeDef", "group___h_a_l__state__structure__definition.html#gaef355af8eab251ae2a19ee164ad81c37", [
      [ "HAL_I2C_STATE_RESET", "group___h_a_l__state__structure__definition.html#ggaef355af8eab251ae2a19ee164ad81c37a91ba08634e08d7287940f1bc5a37eeff", null ],
      [ "HAL_I2C_STATE_READY", "group___h_a_l__state__structure__definition.html#ggaef355af8eab251ae2a19ee164ad81c37af859ce60c5e462b0bfde3a5010bc72d1", null ],
      [ "HAL_I2C_STATE_BUSY", "group___h_a_l__state__structure__definition.html#ggaef355af8eab251ae2a19ee164ad81c37a0c503d6c0388f0d872b368557e278b5a", null ],
      [ "HAL_I2C_STATE_BUSY_TX", "group___h_a_l__state__structure__definition.html#ggaef355af8eab251ae2a19ee164ad81c37acb3a9e3d4d1076e0f4e65f91ca0161bc", null ],
      [ "HAL_I2C_STATE_BUSY_RX", "group___h_a_l__state__structure__definition.html#ggaef355af8eab251ae2a19ee164ad81c37a4ea4ecc2dc3cb64c4877c123d9d73170", null ],
      [ "HAL_I2C_STATE_LISTEN", "group___h_a_l__state__structure__definition.html#ggaef355af8eab251ae2a19ee164ad81c37a13518f06f54c7515100e86bb8d6e0779", null ],
      [ "HAL_I2C_STATE_BUSY_TX_LISTEN", "group___h_a_l__state__structure__definition.html#ggaef355af8eab251ae2a19ee164ad81c37a14d22553a60819b276582e08459f30b0", null ],
      [ "HAL_I2C_STATE_BUSY_RX_LISTEN", "group___h_a_l__state__structure__definition.html#ggaef355af8eab251ae2a19ee164ad81c37a8aec2547eedf1c9924f8efed33e3b5c5", null ],
      [ "HAL_I2C_STATE_ABORT", "group___h_a_l__state__structure__definition.html#ggaef355af8eab251ae2a19ee164ad81c37a2c6f6d1fef0847f9da51153b5c295249", null ],
      [ "HAL_I2C_STATE_TIMEOUT", "group___h_a_l__state__structure__definition.html#ggaef355af8eab251ae2a19ee164ad81c37a378abf24301fe7a23620fd78ff3f168b", null ],
      [ "HAL_I2C_STATE_ERROR", "group___h_a_l__state__structure__definition.html#ggaef355af8eab251ae2a19ee164ad81c37afe3c9b304462901099426a0d414be2a2", null ]
    ] ]
];