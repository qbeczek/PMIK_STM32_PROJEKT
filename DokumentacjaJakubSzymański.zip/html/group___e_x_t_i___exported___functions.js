var group___e_x_t_i___exported___functions =
[
    [ "Configuration functions", "group___e_x_t_i___exported___functions___group1.html", null ],
    [ "IO operation functions", "group___e_x_t_i___exported___functions___group2.html", null ]
];