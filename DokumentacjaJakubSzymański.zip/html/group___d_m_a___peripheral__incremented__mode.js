var group___d_m_a___peripheral__incremented__mode =
[
    [ "DMA_PINC_DISABLE", "group___d_m_a___peripheral__incremented__mode.html#ga63e2aff2973d1a8f01d5d7b6e4894f39", null ],
    [ "DMA_PINC_ENABLE", "group___d_m_a___peripheral__incremented__mode.html#gab6d84e5805302516d26c06fb4497a346", null ]
];