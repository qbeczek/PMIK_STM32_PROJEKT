var group___d_m_a___data__transfer__direction =
[
    [ "DMA_MEMORY_TO_MEMORY", "group___d_m_a___data__transfer__direction.html#ga0695035d725855ccf64d2d8452a33810", null ],
    [ "DMA_MEMORY_TO_PERIPH", "group___d_m_a___data__transfer__direction.html#ga9e76fc559a2d5c766c969e6e921b1ee9", null ],
    [ "DMA_PERIPH_TO_MEMORY", "group___d_m_a___data__transfer__direction.html#gacb2cbf03ecae6804ae4a6f60a3e37c12", null ]
];