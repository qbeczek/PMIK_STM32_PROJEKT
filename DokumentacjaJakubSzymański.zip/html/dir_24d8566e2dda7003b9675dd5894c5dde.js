var dir_24d8566e2dda7003b9675dd5894c5dde =
[
    [ "stm32_hal_legacy.h", "stm32__hal__legacy_8h.html", "stm32__hal__legacy_8h" ]
];