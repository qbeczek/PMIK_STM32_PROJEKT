var group___f_l_a_s_h_ex___option___type =
[
    [ "OPTIONBYTE_BOR", "group___f_l_a_s_h_ex___option___type.html#gaf4063216c8386467d187663190936c07", null ],
    [ "OPTIONBYTE_RDP", "group___f_l_a_s_h_ex___option___type.html#ga8f0bdb21ef13bae39d5d8b6619e2df06", null ],
    [ "OPTIONBYTE_USER", "group___f_l_a_s_h_ex___option___type.html#gac7d843e666e15c79688a1914e8ffe7a5", null ],
    [ "OPTIONBYTE_WRP", "group___f_l_a_s_h_ex___option___type.html#ga48712a166ea192ddcda0f2653679f9ec", null ]
];