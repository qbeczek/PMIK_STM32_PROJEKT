var group___d_m_a__mode =
[
    [ "DMA_CIRCULAR", "group___d_m_a__mode.html#ga4c4f425cba13edffb3c831c036c91e01", null ],
    [ "DMA_NORMAL", "group___d_m_a__mode.html#ga04941acfbbdefc53e1e08133cffa3b8a", null ],
    [ "DMA_PFCTRL", "group___d_m_a__mode.html#ga7974ee645c8e275a2297cf37eec9e022", null ]
];