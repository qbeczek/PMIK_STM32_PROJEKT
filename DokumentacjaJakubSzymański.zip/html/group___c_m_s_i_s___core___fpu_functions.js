var group___c_m_s_i_s___core___fpu_functions =
[
    [ "SAU Functions", "group___c_m_s_i_s___core___s_a_u_functions.html", "group___c_m_s_i_s___core___s_a_u_functions" ],
    [ "Cache Functions", "group___c_m_s_i_s___core___cache_functions.html", "group___c_m_s_i_s___core___cache_functions" ],
    [ "SCB_GetFPUType", "group___c_m_s_i_s___core___n_v_i_c_functions.html#ga6bcad99ce80a0e7e4ddc6f2379081756", null ]
];