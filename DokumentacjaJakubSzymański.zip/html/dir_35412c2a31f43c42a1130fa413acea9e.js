var dir_35412c2a31f43c42a1130fa413acea9e =
[
    [ "bmp280.h", "bmp280_8h.html", "bmp280_8h" ],
    [ "bmp280_defs.h", "bmp280__defs_8h.html", "bmp280__defs_8h" ],
    [ "bmp280_read.h", "bmp280__read_8h.html", "bmp280__read_8h" ],
    [ "fonts.h", "fonts_8h.html", "fonts_8h" ],
    [ "GFX_FUNCTIONS.h", "_g_f_x___f_u_n_c_t_i_o_n_s_8h.html", "_g_f_x___f_u_n_c_t_i_o_n_s_8h" ],
    [ "gpio.h", "gpio_8h.html", "gpio_8h" ],
    [ "i2c.h", "i2c_8h.html", "i2c_8h" ],
    [ "macros.h", "macros_8h.html", "macros_8h" ],
    [ "main.h", "main_8h.html", "main_8h" ],
    [ "onScreen.h", "on_screen_8h.html", "on_screen_8h" ],
    [ "printf_to_UART.h", "printf__to___u_a_r_t_8h.html", "printf__to___u_a_r_t_8h" ],
    [ "spi.h", "spi_8h.html", "spi_8h" ],
    [ "ST7735.h", "_s_t7735_8h.html", "_s_t7735_8h" ],
    [ "stm32f4xx_hal_conf.h", "stm32f4xx__hal__conf_8h_source.html", null ],
    [ "stm32f4xx_it.h", "stm32f4xx__it_8h.html", "stm32f4xx__it_8h" ],
    [ "tim.h", "tim_8h.html", "tim_8h" ],
    [ "usart.h", "usart_8h.html", "usart_8h" ]
];