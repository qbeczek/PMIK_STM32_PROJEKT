var group___c_o_r_t_e_x___exported___functions =
[
    [ "CORTEX_Exported_Functions_Group1", "group___c_o_r_t_e_x___exported___functions___group1.html", null ],
    [ "CORTEX_Exported_Functions_Group2", "group___c_o_r_t_e_x___exported___functions___group2.html", null ]
];