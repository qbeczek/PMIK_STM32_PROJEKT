var group___f_l_a_s_h_ex___type___erase =
[
    [ "FLASH_TYPEERASE_MASSERASE", "group___f_l_a_s_h_ex___type___erase.html#ga9bc03534e69c625e1b4f0f05c3852243", null ],
    [ "FLASH_TYPEERASE_SECTORS", "group___f_l_a_s_h_ex___type___erase.html#gaee700cbbc746cf72fca3ebf07ee20c4e", null ]
];