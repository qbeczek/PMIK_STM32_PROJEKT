var group___c_m_s_i_s___core___function_interface =
[
    [ "CMSIS Core Register Access Functions", "group___c_m_s_i_s___core___reg_acc_functions.html", "group___c_m_s_i_s___core___reg_acc_functions" ],
    [ "NVIC Functions", "group___c_m_s_i_s___core___n_v_i_c_functions.html", "group___c_m_s_i_s___core___n_v_i_c_functions" ]
];