var group___d_m_a___exported___functions =
[
    [ "Initialization and de-initialization functions", "group___d_m_a___exported___functions___group1.html", null ],
    [ "I/O operation functions", "group___d_m_a___exported___functions___group2.html", null ],
    [ "Peripheral State functions", "group___d_m_a___exported___functions___group3.html", null ]
];