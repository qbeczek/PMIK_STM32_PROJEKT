var group___c_o_r_t_e_x___exported___constants =
[
    [ "CORTEX Preemption Priority Group", "group___c_o_r_t_e_x___preemption___priority___group.html", "group___c_o_r_t_e_x___preemption___priority___group" ],
    [ "CORTEX _SysTick clock source", "group___c_o_r_t_e_x___sys_tick__clock__source.html", null ]
];