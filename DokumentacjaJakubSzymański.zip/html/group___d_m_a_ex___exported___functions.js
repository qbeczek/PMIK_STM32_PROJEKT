var group___d_m_a_ex___exported___functions =
[
    [ "Extended features functions", "group___d_m_a_ex___exported___functions___group1.html", null ]
];